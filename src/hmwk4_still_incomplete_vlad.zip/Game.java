public class Game {

    private PlayerHand mainDeck, discardedDeck;
    private Dealer dealer;
    private User user;
    private PlayerHand hand;
    private int win, loss, draw;

    public Game() {

        // creating separate card piles
        mainDeck = new PlayerHand();
        discardedDeck = new PlayerHand();

        // creating the two player classes
        dealer = new Dealer();
        user = new User();

        hand = new PlayerHand();

        startGame();
    }

    private void startGame() {

        Shoe newShoe = new Shoe();
        PlayerHand hand = new PlayerHand();
        dealer.getHand().getRandomCard(newShoe); // does not work


//        dealer.getHand().getCard(0);

//        dealer.getHand().getRandomCard(mainDeck);
//        dealer.getHand().getRandomCard(mainDeck);
//
//        user.getHand().getRandomCard(mainDeck);
//        user.getHand().getRandomCard(mainDeck);

//        dealer.printHands();
//        user.printHands();
    }


}
