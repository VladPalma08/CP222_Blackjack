public class Dealer implements Player {
    private String name;
//    private Shoe shoe;
    private PlayerHand hands;

    public String name() {
        return name;
    }

    public String getName() {
        return name();
    }

    public String setName(String name) {
        this.name = name;
        return name;
    }

    public PlayerHand hand() {
        return hands;
    }

    public void setHand(PlayerHand hand) {
        hands = hand;
    }

    public PlayerHand getHand() { return this.hands; }

//    public void printHands() {
//        System.out.println(this.name + "'s hand looks like this:");
//        System.out.println(getHand().getCard(0));
//        System.out.println("The second card is not shown.");
//    }

    public Dealer() {
        setName("The Dealer");
    }
}