import java.util.Scanner;

public class Main {

    static Card newCard = new Card(Value.King, Suit.Spades);
    static Shoe newShoe = new Shoe();

    public static void main(String[] args) {

        System.out.print("Welcome to Terminal Black Jack. Please enter your name: ");
        User test = new User();
        Scanner scanner = new Scanner(System.in);
        test.setName(scanner.nextLine());
        System.out.println("Name: " + test.getName());

        Dealer testTwo = new Dealer();
        System.out.println("Dealer Name: " + testTwo.getName());

        Game newGame = new Game();
//
//
//        PlayerHand hand = new PlayerHand();
//        hand.getRandomCard(newShoe);
//        hand.getRandomCard(newShoe);
//        System.out.println(hand);
//        System.out.println("Hand total is: " + hand.totalPoints());
//
//        System.out.println("Black Jack?: " + hand.isBlackJack());




    }
}