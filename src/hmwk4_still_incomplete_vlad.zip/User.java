public class User implements Player {

    private String name;
//    private Shoe shoe;
    private PlayerHand hands;

    public String name() {
        return name;
    }

    public String getName() {
        return name();
    }

    public String setName(String name) {
        this.name = name;
        return name;
    }

    public PlayerHand hand() { return hands; }

    public PlayerHand getHand() {
        return this.hands;
    }

    public void setHand(PlayerHand hand) { hands = hand; }

    public User() {
        setName("Player");
    }

//    public void printHands() {
//        System.out.println(this.name + "'s hand looks like this:");
//        System.out.println(this.hands + " Valued at: " + this.hands.totalPoints());
//    }

    public void userTurn() {

    }
}
