Sources:
https://kevinsguides.com/guides/code/java/javaprojs/consoleblackjack
https://stackoverflow.com/questions/7833689/java-string-new-line
https://codehs.com/sandbox/apcsa/the-blackjack-game?filepath=Hand.java
https://codehs.com/sandbox/jkeesh/java-user-input-scanner

Answers to part 3
Clear instructions for how to run and use your program

Reflect on the process of planning and then building the program.
Which parts of the design plan did you end up changing during implementation,
and why? Which data structures did you use to store information?
Why did you choose them, and did they end up working as you expected?
What parts of the implementation were harder or easier than you had anticipated?