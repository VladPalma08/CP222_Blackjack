public interface Player {

    PlayerHand hand();
    String name();

//    PlayerHand getHand();
    void setHand(PlayerHand hand);

    String getName();
    String setName(String name);

}
