import java.util.*;

public class Shoe {

    List<Card> cards;

    public Shoe() {
        this.cards = getEmptyCardList();
        addDeckOfCards();
        shuffleCards();
    }

    public Shoe(List<Card> cards) {
        this.cards = cards;
    }

    List<Card> getEmptyCardList() {
        return new ArrayList<Card>();
    }

    public void addDeckOfCards() {
        for(int value = 1; value <= 13; value++) {
            for (Suit suit : Suit.values()) {
                cards.add(new Card(value, suit));
            }
        }
    }

    public void shuffleCards() {
        List<Card> newPile = getEmptyCardList();
        while(!cards.isEmpty()) {
            Card pickedCard = getRandomCardFromCards();
            newPile.add(pickedCard);
        }
        cards = newPile;
    }

    Card getRandomCardFromCards() {
        Random rand = new Random();
        int index = rand.nextInt(cards.size());
        return cards.remove(index);
    }

    public static void main(String[] args) {
        Shoe newShoe = new Shoe();
        System.out.println(newShoe);
    }

}
