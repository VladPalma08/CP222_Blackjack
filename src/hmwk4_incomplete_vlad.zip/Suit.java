enum Suit {
    Spades, Hearts, Clubs, Diamonds
}