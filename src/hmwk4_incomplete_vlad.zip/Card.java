public class Card {

    int value;
    Suit suit;
    // char suit; //

    public Card(int value, Suit suit) {
        this.value = value;
        this.suit = suit;
    }

    boolean isBlackJack() {
        return (value == 11 && suit == Suit.Spades || suit == Suit.Clubs);
    }

//    int getBlackJackValue() {
//
//    }

}
