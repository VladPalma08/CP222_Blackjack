public class Card {

    Value value;
    Suit cardSuit;

    public Card(Value cardValue, Suit suit) {
        value = cardValue;
        cardSuit = suit;
    }

    // methods required: getCardValueName, getCardValueNumber, getCardSuit
    public Suit getCardSuit() {
        return cardSuit;
    }

    public Value getCardValueName() {
        return value;
    }

    public int getCardValueNumber() {
        return value.cardValue;
    }

    // printing out cards and their values
    public String toString() {
        if (this.getCardValueNumber() <= 9) {
            return "\n╷———————╷ " +
                    "\n│ " + this.getCardValueNumber() + "     │ " +
                    "\n│   " + cardSuit + "   │ " +
                    "\n│     " + this.getCardValueNumber() + " │ " +
                    "\n╵———————╵" +
                    "\n[" + getCardValueName() + " of " + cardSuit +
                    "] (" + getCardValueNumber() + ")";
        }
        else if (this.getCardValueNumber() >= 10) {
            return "\n╷————————╷ " +
                    "\n│ " + this.getCardValueNumber() + "     │ " +
                    "\n│   " + cardSuit + "    │ " +
                    "\n│     " + this.getCardValueNumber() + " │ " +
                    "\n╵————————╵" +
                    "\n[" + getCardValueName() + " of " + cardSuit +
                    "] (" + getCardValueNumber() + ")";
        }
        return null;
    }

}

//"\nThe " + getCardValueName() + " of " + cardSuit +
//        " has a value of " + getCardValueNumber();

//    int getBlackJackValue() {
//
//    }
