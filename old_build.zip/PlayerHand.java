import java.util.ArrayList;

public class PlayerHand {

    private ArrayList<Card> hand;

    public PlayerHand() {
        hand = new ArrayList<Card>();
    }

    public void getRandomCard(Shoe cards) {
        hand.add(cards.getRandomCardFromCards());
    }

    public Card getCard(int index) {
        return hand.get(index);
    }

    // algorithm for getting the total points based on hand (required an online resource)
    public int totalPoints() {
        int total = 0;
        int numAces = 0;

        for(Card c : hand) {
            total += c.getCardValueNumber();

            if(c.getCardValueName() == Value.Ace) {
                numAces++;
            }
        }
        while(total > 21 && numAces > 0) {
            total -= 10;
            numAces--;
        }
        return total;
    }

    // returns value when a "Black Jack" is detected
    public boolean isBlackJack() {
        if(totalPoints() == 21) {
            return true;
        }
        else {
            return false;
        }
    }

    // returns value when the total points go over 21
    public boolean busted() {
        return totalPoints() > 21;
    }

    // returns value when hand size reaches 5 without busting
    public boolean fiveCardCondition() {
        return hand.size() == 5;
    }

    public String toString() {
        String handResult = "";
        for (Card card : hand) {
            handResult += card;
        }
        return handResult;
    }
}

// BlackJack method below: (I don't actually know how to play the game)

//    public boolean isBlackJack(Shoe card) {
//        if (totalPoints() == 10 && hand.size() == 2 && card.getRandomCardFromCards().getCardValueName() == Value.Ace
//            && card.getRandomCardFromCards().getCardSuit() == Suit.Clubs
//                || card.getRandomCardFromCards().getCardSuit() == Suit.Spades) {
//            return true;
//        }
//        else {
//            return false;
//        }
//    }
